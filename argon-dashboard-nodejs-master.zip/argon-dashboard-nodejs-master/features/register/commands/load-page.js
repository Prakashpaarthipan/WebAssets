async function loadPage(req, res) {
  res.render('pages/register');
}

module.exports = loadPage;

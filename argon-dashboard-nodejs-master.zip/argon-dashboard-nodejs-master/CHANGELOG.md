# Change Log

## [1.0.0] 2019-03-04
### Initial Release

## [1.0.1] 2019-03-14
- Remove unnecessary body tag;

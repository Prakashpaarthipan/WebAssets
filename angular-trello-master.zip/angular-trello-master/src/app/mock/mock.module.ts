// TODO looks like we always need a reducer for top level reducers so create a mock here
// TODO remove later
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: []
})
export class MockModule { }

export class Board {
  name: string;
}

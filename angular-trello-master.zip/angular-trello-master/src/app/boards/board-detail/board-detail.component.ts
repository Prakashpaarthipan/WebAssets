import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-board-detail',
  template: `
    <p>
      board-detail works!
    </p>
  `,
  styleUrls: ['./board-detail.component.scss']
})
export class BoardDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

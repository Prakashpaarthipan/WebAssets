import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-profile',
  template: `
    <p>
      edit-profile works!
    </p>
  `,
  styleUrls: ['./edit-profile.component.scss']
})
export class EditProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
